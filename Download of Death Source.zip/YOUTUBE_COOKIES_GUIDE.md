# How to Export YouTube Cookies to Fix Bot Detection

## The Problem

YouTube has become increasingly aggressive about detecting automated downloads and will sometimes block them with the error:
```
Sign in to confirm you're not a bot
```

The solution is to export your browser's cookies and provide them to the downloader, so it can authenticate as if you're logged in.

---

## Solution: Export Cookies from Your Browser

### Step 1: Install a Cookies Export Extension

Choose the extension for your browser:

#### Chrome / Edge / Brave
Install **"Get cookies.txt LOCALLY"** extension:
1. Go to Chrome Web Store
2. Search for "Get cookies.txt LOCALLY" (by Rahul Shaw)
3. Click "Add to Chrome" / "Add to Edge"
4. Confirm the installation

**Direct link:** https://chrome.google.com/webstore/detail/get-cookiestxt-locally/cclelndahbckbenkjhflpdbgdldlbecc

#### Firefox
Install **"cookies.txt"** extension:
1. Go to Firefox Add-ons
2. Search for "cookies.txt"
3. Click "Add to Firefox"
4. Confirm the installation

**Direct link:** https://addons.mozilla.org/en-US/firefox/addon/cookies-txt/

#### Safari
Install **"Get cookies.txt LOCALLY"**:
1. Available on Mac App Store
2. Or use Firefox/Chrome method

---

### Step 2: Export YouTube Cookies

1. **Open YouTube in your browser** and make sure you're logged in
2. **Navigate to any YouTube page** (e.g., https://www.youtube.com)
3. **Click the cookies extension icon** in your browser toolbar
4. **Click "Export"** or "Download" button
5. **Save the file** as `youtube_cookies.txt` to an easy location (Desktop or Downloads)

**Important Notes:**
- You must be on youtube.com when exporting
- The file should be named with `.txt` extension
- Keep this file private - it contains your login session!

---

### Step 3: Use Cookies in Download of Death

1. **Open Download of Death**
2. **Click "Select Cookies File (Optional)"**
3. **Browse to your saved** `youtube_cookies.txt` file
4. **Select it** - you'll see "Cookies file loaded!" message
5. **Try your download again** - it should now work!

---

## Troubleshooting

### "Still getting bot detection error"

**Solution 1: Refresh the cookies**
- Your cookies might have expired
- Re-export fresh cookies from your browser
- Make sure you're logged into YouTube when exporting

**Solution 2: Clear browser cache**
- Sometimes old sessions cause issues
- Log out of YouTube completely
- Clear your browser's cookies and cache
- Log back in
- Export new cookies

**Solution 3: Try a different browser**
- Some browsers have better cookie export
- Chrome/Edge generally work most reliably

### "Cookies file doesn't work"

**Check the file format:**
```
# Netscape HTTP Cookie File
.youtube.com    TRUE    /    TRUE    1234567890    CONSENT    YES+...
.youtube.com    TRUE    /    FALSE   1234567890    VISITOR_INFO1_LIVE    ...
```

The file should:
- Start with `# Netscape HTTP Cookie File`
- Contain multiple lines with `.youtube.com`
- Be plain text (not HTML or JSON)

### "Extension not available for my browser"

**Alternative: Manual export using browser DevTools**
1. Open YouTube
2. Press F12 (Developer Tools)
3. Go to "Application" tab (Chrome) or "Storage" tab (Firefox)
4. Click "Cookies" → "https://www.youtube.com"
5. This is complex - better to use an extension!

---

## Privacy & Security

**Important Security Notes:**

⚠️ **Cookies are like passwords** - they give access to your account!

- **Never share** your cookies file with anyone
- **Don't upload** cookies files to public websites
- **Delete old cookies files** when done
- **Regenerate cookies** monthly for security
- **Keep the file safe** - treat it like a password file

The cookies file contains session tokens that allow access to your YouTube account. If someone gets your cookies file, they can access your account!

---

## How Long Do Cookies Last?

- **YouTube cookies typically last:** 6 months to 1 year
- **Session cookies last:** Until you log out
- **Re-export periodically** if you get errors again

---

## Alternative: Browser-based Download Extensions

If you don't want to manage cookies files, consider these alternatives:
- Browser extensions that download directly from YouTube
- Online YouTube downloaders (be careful with privacy)
- YouTube Premium (supports offline downloads natively)

However, Download of Death with cookies gives you:
- ✓ Batch downloading
- ✓ Format conversion (MP3, WAV, FLAC)
- ✓ Queue management
- ✓ Better control over output

---

## Quick Reference

**Summary of steps:**
1. Install cookies export extension for your browser
2. Go to YouTube (logged in)
3. Click extension → Export cookies
4. Save as `youtube_cookies.txt`
5. In Download of Death → "Select Cookies File"
6. Choose your cookies file
7. Download works!

**When to re-export cookies:**
- Every 1-6 months (when they expire)
- When you get bot detection errors again
- After logging out/in to YouTube
- After clearing browser data
