# Quick Reference: YouTube Download Errors

## Error Decoder

Match your error message to find the solution:

---

### ❌ "HTTP 403 Forbidden"

**Cause:** N parameter challenge (JavaScript required)

**Fix:**
1. Install Node.js from https://nodejs.org/
2. Restart computer
3. Try again

**Time:** 5 minutes

---

### ❌ "Requested format is not available" / "Only images available"

**Cause:** PO Token protection (newest anti-bot measure)

**Fix:**
1. Update yt-dlp: `pip install --upgrade yt-dlp`
2. Restart Download of Death
3. Try MP3 format instead of MP4
4. If still fails, wait 30min and retry

**Time:** 2 minutes

---

### ❌ "Sign in to confirm you're not a bot"

**Cause:** Need cookies OR cookies expired

**Fix:**
1. Export cookies from browser (use cookies.txt extension)
2. Load in Download of Death
3. OR re-export if you already had cookies loaded

**Time:** 3 minutes

---

### ❌ "The provided cookies are no longer valid"

**Cause:** Cookies expired (normal, happens every few weeks)

**Fix:**
1. Go to youtube.com in browser (logged in)
2. Export new cookies with extension
3. Load new cookies file in app

**Time:** 2 minutes

---

### ❌ "The downloaded file is empty" / "0 bytes"

**Cause:** Video restricted, blocked, or authentication failed

**Fix:**
1. Try with cookies file
2. Update yt-dlp
3. Check video works in browser
4. Try different video

---

### ❌ "429 Too Many Requests"

**Cause:** Rate limited by YouTube

**Fix:**
1. Wait 15-30 minutes
2. Don't download too many at once
3. Use cookies
4. Try again later

---

## Complete Setup Checklist

**For best results, you need ALL of these:**

### ☑️ Software Requirements

- [ ] **Python 3.8+** installed
- [ ] **yt-dlp** latest version: `pip install --upgrade yt-dlp`
- [ ] **Node.js** installed: https://nodejs.org/
- [ ] **PO Token Plugin**: `pip install bgutil-ytdlp-pot-provider`
- [ ] **FFmpeg** bundled with app (automatic)

### ☑️ Configuration

- [ ] **Fresh cookies** exported from browser
- [ ] **Cookies loaded** in Download of Death
- [ ] **Cookies extension** still installed in browser

### ☑️ Verify Setup

**Run these commands:**

```bash
# Check Python
python --version
# Should be 3.8 or higher

# Check Node.js  
node --version
# Should be v20.x or higher

# Check yt-dlp
yt-dlp --version
# Should be 2025.x or later

# Check PO Token Plugin
pip show bgutil-ytdlp-pot-provider
# Should show installed

# Test yt-dlp works
yt-dlp -F "https://www.youtube.com/watch?v=jNQXAC9IVRw"
# Should list available formats
```

---

## Decision Tree

**Follow this flowchart:**

```
Can't download video?
   |
   ├─> Error has "403 Forbidden"?
   |   └─> Install Node.js → Restart → Try again
   |
   ├─> Error has "format not available"?
   |   └─> Update yt-dlp → Try MP3 format → Wait 30min
   |
   ├─> Error has "bot" or "sign in"?
   |   └─> Export fresh cookies → Load in app
   |
   ├─> Error has "cookies no longer valid"?
   |   └─> Re-export cookies from browser
   |
   ├─> Error has "empty" or "0 bytes"?
   |   └─> Load cookies → Update yt-dlp → Try different video
   |
   └─> Other error?
       └─> Turn on Verbose Mode → Check console output
```

---

## Monthly Maintenance

**Do this every month to prevent issues:**

### Week 1
- [ ] Update yt-dlp: `pip install --upgrade yt-dlp`
- [ ] Update PO Token plugin: `pip install --upgrade bgutil-ytdlp-pot-provider`
- [ ] Update Node.js if needed
- [ ] Test with a known video

### Week 2-3
- [ ] Re-export fresh cookies
- [ ] Replace old cookies file

### Week 4
- [ ] Rebuild Download of Death with latest yt-dlp

**This prevents 90% of download errors.**

---

## Priority Actions

**If you only do FOUR things:**

### 1. Install PO Token Plugin
```bash
pip install bgutil-ytdlp-pot-provider
```
Fixes YouTube's latest anti-bot protection.

### 2. Keep yt-dlp updated
```bash
pip install --upgrade yt-dlp
```
YouTube changes constantly - old versions stop working.

### 3. Have Node.js installed
https://nodejs.org/

Required for most videos now.

### 4. Use fresh cookies
Re-export every few weeks.

---

## When to Give Up on a Video

**Some videos genuinely can't be downloaded:**

- Members-only content
- Active livestreams  
- DRM-protected music videos
- Videos with extra restrictions

**Signs it's impossible:**
- Multiple methods all fail
- Audio-only fails too
- Works in browser but not any downloader
- Other videos from channel work fine

**Try:**
- Wait 24-48 hours
- Different video from same channel
- Older/less popular video

---

## Emergency Fixes

### Reset Everything

```bash
# Update all tools
pip install --upgrade yt-dlp
pip install --upgrade PyQt6

# Clear cache
pip cache purge

# Reinstall yt-dlp
pip uninstall yt-dlp
pip install yt-dlp

# Restart computer
# Re-export fresh cookies
# Try again
```

### Run Without GUI

```bash
# Use yt-dlp directly
yt-dlp --cookies cookies.txt "VIDEO_URL"
```

If this works, Download of Death needs rebuilding.

---

## Support Resources

**Guides included:**
- `QUICK_FIX_403.md` - Node.js installation
- `PO_TOKEN_ERROR.md` - Format not available
- `COOKIES_EXPIRED.md` - Cookie management
- `NODEJS_REQUIREMENT.md` - Detailed Node.js guide
- `TROUBLESHOOTING_DOWNLOADS.md` - Complete troubleshooting

**For latest info:**
- yt-dlp GitHub: https://github.com/yt-dlp/yt-dlp
- yt-dlp issues: Common problems and solutions

---

## Version Compatibility

**Current requirements (as of Jan 2025):**

- **Python:** 3.8+ (3.10+ recommended)
- **yt-dlp:** 2025.x or later
- **Node.js:** v20+ (LTS)
- **PyQt6:** Latest
- **FFmpeg:** Any recent version

**If using older versions, many downloads will fail.**

---

## Summary

**Most common issues:**

1. **403 Forbidden** → Install Node.js
2. **Format not available** → Install PO Token plugin: `pip install bgutil-ytdlp-pot-provider`
3. **Bot detection** → Use cookies
4. **Cookies invalid** → Re-export fresh cookies

**Do monthly:**
- Update yt-dlp
- Update PO Token plugin
- Refresh cookies  
- Check Node.js installed

**That's it!**
