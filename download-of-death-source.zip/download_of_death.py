from __future__ import annotations

import sys
import time
from pathlib import Path
import threading

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QObject
from PyQt6.QtGui import (
    QFont, QPainter, QPixmap, QColor,
    QGuiApplication, QPalette, QIcon
)
from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QFileDialog, QMessageBox,
    QComboBox, QProgressBar, QListWidget, QTextEdit,
    QSplashScreen, QDialog, QDialogButtonBox
)

import yt_dlp

APP_NAME = "Download of Death"
ORG_NAME = "Death's Head Software"
HISTORY_FILE = Path.home() / ".download_of_death_history.log"


# =============================================================================
# STDERR FILTER (suppresses harmless Python 3.14 http.client warnings)
# =============================================================================

import contextlib

class StderrFilter:
    """Filter out specific harmless error messages from stderr."""
    def __init__(self):
        self.stderr = sys.stderr if sys.stderr is not None else sys.__stderr__
        self.filtered_phrases = [
            "I/O operation on closed file",
            "Exception ignored while finalizing",
        ]
    
    def write(self, message):
        # Safely write, checking for None
        if self.stderr is None:
            return
        try:
            # Only write if message doesn't contain filtered phrases
            if not any(phrase in message for phrase in self.filtered_phrases):
                self.stderr.write(message)
        except (AttributeError, ValueError, OSError):
            # Ignore errors if stderr is closed or unavailable
            pass
    
    def flush(self):
        if self.stderr is not None:
            try:
                self.stderr.flush()
            except (AttributeError, ValueError, OSError):
                pass
    
    def fileno(self):
        if self.stderr is not None:
            try:
                return self.stderr.fileno()
            except (AttributeError, ValueError, OSError):
                return -1
        return -1

@contextlib.contextmanager
def suppress_http_warnings():
    """Temporarily filter stderr to hide harmless http.client warnings."""
    old_stderr = sys.stderr
    try:
        sys.stderr = StderrFilter()
        yield
    except Exception:
        # If anything goes wrong, restore stderr immediately
        sys.stderr = old_stderr
        raise
    finally:
        # Always restore original stderr
        sys.stderr = old_stderr


# =============================================================================
# FFMPEG PATH DETECTION
# =============================================================================

def get_ffmpeg_path():
    """Locate bundled FFmpeg executable - supports both --onefile and --onedir."""
    locations_to_check = []
    
    if getattr(sys, 'frozen', False):
        # Running as bundled executable
        base = Path(sys._MEIPASS)
        
        if sys.platform == "darwin":
            # For macOS --onedir, PyInstaller puts files in Contents/MacOS/ when using "."
            # Check multiple possible locations
            locations_to_check = [
                base,                        # Contents/MacOS/ (--onedir with ".")
                base / "ffmpeg",             # Contents/MacOS/ffmpeg/ (--onefile)
                base.parent / "Frameworks",  # Contents/Frameworks/ (if manually moved)
            ]
        elif sys.platform == "win32":
            locations_to_check = [base / "ffmpeg", base]
        else:  # Linux
            locations_to_check = [base / "ffmpeg", base]
    else:
        # Running as script
        locations_to_check = [Path(__file__).parent / "ffmpeg"]
    
    # Check each location
    for location in locations_to_check:
        if sys.platform == "win32":
            ffmpeg = location / "ffmpeg.exe"
            ffprobe = location / "ffprobe.exe"
        else:
            ffmpeg = location / "ffmpeg"
            ffprobe = location / "ffprobe"
        
        if ffmpeg.exists() and ffprobe.exists():
            return str(ffmpeg), str(ffprobe)

    # Not found in bundled locations — try system PATH and common install dirs
    import shutil
    ffmpeg_bin  = "ffmpeg.exe"  if sys.platform == "win32" else "ffmpeg"
    ffprobe_bin = "ffprobe.exe" if sys.platform == "win32" else "ffprobe"

    ffmpeg_sys  = shutil.which(ffmpeg_bin)
    ffprobe_sys = shutil.which(ffprobe_bin)
    if ffmpeg_sys and ffprobe_sys:
        return ffmpeg_sys, ffprobe_sys

    # WinGet and common Windows install locations
    if sys.platform == "win32":
        winget_base = Path.home() / "AppData/Local/Microsoft/WinGet/Packages"
        extra_roots = []
        if winget_base.exists():
            for pkg in winget_base.iterdir():
                if "ffmpeg" in pkg.name.lower():
                    for bin_dir in pkg.rglob("bin"):
                        extra_roots.append(bin_dir)
        extra_roots += [
            Path("C:/ffmpeg/bin"),
            Path("C:/Program Files/ffmpeg/bin"),
            Path("C:/Program Files (x86)/ffmpeg/bin"),
        ]
        for root in extra_roots:
            f = root / "ffmpeg.exe"
            p = root / "ffprobe.exe"
            if f.exists() and p.exists():
                return str(f), str(p)

    return None, None


# =============================================================================
# ICON PATH DETECTION
# =============================================================================

def get_icon_path():
    """Locate bundled icon file for taskbar/window icon."""
    icon_name = "icon.ico" if sys.platform == "win32" else "icon.icns"
    
    if getattr(sys, 'frozen', False):
        # Running as bundled executable
        base = Path(sys._MEIPASS)
        icon_path = base / icon_name
        if icon_path.exists():
            return str(icon_path)
    else:
        # Running as script
        icon_path = Path(__file__).parent / icon_name
        if icon_path.exists():
            return str(icon_path)
    
    return None


# =============================================================================
# PALETTE (UNCHANGED)
# =============================================================================

def apply_dark_palette(app):
    p = QPalette()
    window   = QColor(0, 0, 0)          # pure black background
    base     = QColor(10, 10, 10)       # slightly off-black for inputs
    button   = QColor(20, 20, 20)       # dark button background
    text     = QColor(0, 220, 0)        # green text
    dim_text = QColor(0, 140, 0)        # dimmer green for placeholders
    highlight = QColor(0, 160, 0)       # green highlight bar
    border   = QColor(0, 100, 0)        # dark green border

    for g in (QPalette.ColorGroup.Active, QPalette.ColorGroup.Inactive):
        p.setColor(g, QPalette.ColorRole.Window,          window)
        p.setColor(g, QPalette.ColorRole.WindowText,      text)
        p.setColor(g, QPalette.ColorRole.Base,            base)
        p.setColor(g, QPalette.ColorRole.AlternateBase,   QColor(5, 5, 5))
        p.setColor(g, QPalette.ColorRole.Text,            text)
        p.setColor(g, QPalette.ColorRole.PlaceholderText, dim_text)
        p.setColor(g, QPalette.ColorRole.Button,          button)
        p.setColor(g, QPalette.ColorRole.ButtonText,      text)
        p.setColor(g, QPalette.ColorRole.Highlight,       highlight)
        p.setColor(g, QPalette.ColorRole.HighlightedText, QColor(0, 0, 0))
        p.setColor(g, QPalette.ColorRole.Mid,             border)
        p.setColor(g, QPalette.ColorRole.Dark,            QColor(0, 60, 0))
        p.setColor(g, QPalette.ColorRole.Shadow,          QColor(0, 0, 0))
        p.setColor(g, QPalette.ColorRole.Link,            text)

    p.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.WindowText, dim_text)
    p.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.Text,       dim_text)
    p.setColor(QPalette.ColorGroup.Disabled, QPalette.ColorRole.ButtonText, dim_text)

    app.setPalette(p)
    app.setStyleSheet("""
        QWidget {
            background-color: #000000;
            color: #00dc00;
            font-family: Courier;
        }
        QLineEdit, QListWidget, QComboBox, QTextEdit {
            background-color: #0a0a0a;
            color: #00dc00;
            border: 1px solid #006400;
            selection-background-color: #00a000;
            selection-color: #000000;
        }
        QComboBox QAbstractItemView {
            background-color: #0a0a0a;
            color: #00dc00;
            selection-background-color: #006400;
        }
        QPushButton {
            background-color: #0a0a0a;
            color: #00dc00;
            border: 1px solid #006400;
            padding: 4px 10px;
        }
        QPushButton:hover {
            background-color: #003000;
            border: 1px solid #00dc00;
        }
        QPushButton:pressed {
            background-color: #005000;
        }
        QPushButton:disabled {
            color: #005000;
            border: 1px solid #003000;
        }
        QProgressBar {
            background-color: #0a0a0a;
            color: #00dc00;
            border: 1px solid #006400;
            text-align: center;
        }
        QProgressBar::chunk {
            background-color: #00a000;
        }
        QLabel {
            color: #00dc00;
        }
        QMessageBox {
            background-color: #000000;
            color: #00dc00;
        }
        QScrollBar:vertical {
            background: #0a0a0a;
            border: 1px solid #006400;
            width: 12px;
        }
        QScrollBar::handle:vertical {
            background: #006400;
            min-height: 20px;
        }
        QScrollBar::handle:vertical:hover {
            background: #00a000;
        }
    """)


# =============================================================================
# SPLASH (RESTORED – 5.5s)
# =============================================================================

def create_splash(message: str):
    # Find splash.png in bundled app
    if getattr(sys, 'frozen', False):
        base = Path(sys._MEIPASS)
        # Check multiple possible locations for macOS
        if sys.platform == "darwin":
            splash_locations = [
                base / "splash.png",                        # MacOS folder (--onedir with ".")
                base / ".." / "Resources" / "splash.png",   # Resources folder (alternative)
                base.parent / "Resources" / "splash.png",   # Resources folder (alternative)
                base / "Resources" / "splash.png",          # If Resources is under _MEIPASS
            ]
        else:
            splash_locations = [base / "splash.png"]
        
    else:
        splash_locations = [Path(__file__).parent / "splash.png"]
    
    # Try each location
    splash_path = None
    for loc in splash_locations:
        if loc.exists():
            splash_path = loc
            break
    
    if splash_path:
        pixmap = QPixmap(str(splash_path)).scaled(
            800, 600,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
    else:
        pixmap = QPixmap(800, 600)
        pixmap.fill(QColor(0, 0, 0))

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    painter.setPen(QColor("white"))
    painter.setFont(QFont("Courier", 34, QFont.Weight.Bold))
    painter.drawText(pixmap.rect().adjusted(0, 40, 0, -480), Qt.AlignmentFlag.AlignCenter, APP_NAME)

    painter.setFont(QFont("Courier", 12))
    painter.drawText(pixmap.rect().adjusted(0, 480, 0, -90), Qt.AlignmentFlag.AlignCenter, ORG_NAME)

    painter.setFont(QFont("Courier", 11))
    painter.drawText(pixmap.rect().adjusted(0, 520, 0, 0), Qt.AlignmentFlag.AlignCenter, message)

    painter.end()
    return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)


# =============================================================================
# PROGRESS EMITTER
# =============================================================================

class ProgressEmitter(QObject):
    progress = pyqtSignal(int)
    status = pyqtSignal(str)


# =============================================================================
# DOWNLOAD WORKER (FIXED CANCEL / VERBOSE)
# =============================================================================

class DownloadWorker(QThread):
    finished = pyqtSignal(bool)  # True = normal, False = cancelled
    error = pyqtSignal(str)

    def __init__(self, url, out_dir, fmt, emitter, cookies_file=None, browser_cookies=None):
        super().__init__()
        self.url = url
        self.out_dir = out_dir
        self.fmt = fmt
        self.emitter = emitter
        self.cookies_file = cookies_file
        self.browser_cookies = browser_cookies

        self._pause = threading.Event()
        self._pause.set()
        self._cancelled = False

    def pause(self):
        self.emitter.status.emit("Paused")
        self._pause.clear()

    def resume(self):
        self.emitter.status.emit("Resuming download…")
        self._pause.set()

    def cancel(self):
        self._cancelled = True
        self._pause.set()
        self.emitter.status.emit("Cancelling current download…")

    def run(self):
        # Strip any proxy environment variables that could block yt-dlp when
        # the local proxy (e.g. Proxies of Death at 127.0.0.1:1933) is not running.
        import os as _os
        for _pvar in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy",
                      "ALL_PROXY", "all_proxy"):
            _os.environ.pop(_pvar, None)

        try:
            # Verify output directory exists and is valid
            if not self.out_dir or not isinstance(self.out_dir, Path):
                raise Exception("Invalid output directory")
            
            # Ensure output directory exists
            try:
                self.out_dir.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                raise Exception(f"Cannot create output directory: {e}")
            
            def hook(d):
                while not self._pause.is_set():
                    time.sleep(0.2)

                if self._cancelled:
                    raise StopIteration

                if d["status"] == "downloading":
                    downloaded = d.get("downloaded_bytes", 0)
                    total = d.get("total_bytes") or d.get("total_bytes_estimate", 1)
                    pct = int((downloaded / max(total, 1)) * 100)
                    self.emitter.progress.emit(pct)
                    self.emitter.status.emit(f"Downloading… {pct}%")

                elif d["status"] == "finished":
                    self.emitter.progress.emit(100)
                    self.emitter.status.emit("Finalizing file…")

            # Get bundled FFmpeg paths
            ffmpeg_path, ffprobe_path = get_ffmpeg_path()
            
            opts = {
                "outtmpl": str(self.out_dir / "%(title)s.%(ext)s"),
                "progress_hooks": [hook],
                "quiet": True,
                "no_warnings": True,
                "noplaylist": True,
                "force_ipv4": True,
                "retries": 10,
                "fragment_retries": 10,
                "skip_unavailable_fragments": True,
                # Bypass SSL issues caused by VPNs, proxies, or ISP interception
                "nocheckcertificate": True,
                # Use Node.js for JS challenge solving (required for modern YouTube)
                "js_runtimes": {"node": {}},
                "extractor_args": {
                    "youtube": {
                        "player_client": ["web_creator", "tv_embedded", "mweb", "web"],
                    }
                },
            }
            
            # Add FFmpeg paths — try WinGet first (most reliable on Windows),
            # then fall back to bundled folder, then system PATH
            ffmpeg_set = False
            if sys.platform == "win32":
                winget_base = Path.home() / "AppData/Local/Microsoft/WinGet/Packages"
                if winget_base.exists():
                    for pkg in sorted(winget_base.iterdir()):
                        if "ffmpeg" in pkg.name.lower():
                            for bin_dir in pkg.rglob("bin"):
                                if (bin_dir / "ffmpeg.exe").exists() and (bin_dir / "ffprobe.exe").exists():
                                    opts["ffmpeg_location"] = str(bin_dir.resolve())
                                    ffmpeg_set = True
                                    break
                        if ffmpeg_set:
                            break

            if not ffmpeg_set and ffmpeg_path:
                opts["ffmpeg_location"] = str(Path(ffmpeg_path).parent.resolve())
                ffmpeg_set = True


            
            # Add cookies — file takes priority, then explicit browser selection
            if self.cookies_file:
                opts["cookiefile"] = str(self.cookies_file)
            elif self.browser_cookies:
                opts["cookiesfrombrowser"] = self.browser_cookies

            # Build a list of strategies to attempt in order.
            # Each is a dict of overrides merged into base opts.
            # We try them until one succeeds or all fail.
            base_opts = opts.copy()

            strategies = [
                # 1. web_creator — skips PO token enforcement on most videos
                {
                    "extractor_args": {"youtube": {
                        "player_client": ["web_creator"],
                        "player_skip": ["webpage", "configs"],
                    }},
                    "format": "bestvideo+bestaudio/best" if self.fmt not in ("MP3","WAV","FLAC") else "bestaudio/best",
                },
                # 2. tv_embedded — another PO-token-free client
                {
                    "extractor_args": {"youtube": {
                        "player_client": ["tv_embedded"],
                        "player_skip": ["webpage", "configs"],
                    }},
                    "format": "bestvideo+bestaudio/best" if self.fmt not in ("MP3","WAV","FLAC") else "bestaudio/best",
                },
                # 3. ios — works for many videos, uses different format IDs
                {
                    "extractor_args": {"youtube": {
                        "player_client": ["ios"],
                    }},
                    "format": "best" if self.fmt not in ("MP3","WAV","FLAC") else "bestaudio/best",
                },
                # 4. android_vr — another client that avoids PO tokens
                {
                    "extractor_args": {"youtube": {
                        "player_client": ["android_vr"],
                    }},
                    "format": "best" if self.fmt not in ("MP3","WAV","FLAC") else "bestaudio/best",
                },
                # 5. mweb fallback — last resort
                {
                    "extractor_args": {"youtube": {
                        "player_client": ["mweb"],
                        "player_skip": ["webpage"],
                    }},
                    "format": "best" if self.fmt not in ("MP3","WAV","FLAC") else "bestaudio/best",
                },
            ]

            # Apply audio postprocessor to all strategies if needed
            if self.fmt in ("MP3", "WAV", "FLAC"):
                audio_pp = [{
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": self.fmt.lower(),
                    "preferredquality": "0",
                }]
                for s in strategies:
                    s["postprocessors"] = audio_pp
            else:
                for s in strategies:
                    s["merge_output_format"] = self.fmt.lower()

            last_error = None
            success = False

            for i, strategy in enumerate(strategies):
                if self._cancelled:
                    raise StopIteration

                attempt_opts = base_opts.copy()
                attempt_opts.update(strategy)
                # Always re-apply ffmpeg_location — update() can't drop it but
                # ensure it survives the merge explicitly
                if "ffmpeg_location" in base_opts:
                    attempt_opts["ffmpeg_location"] = base_opts["ffmpeg_location"]


                self.emitter.status.emit(f"Trying method {i+1} of {len(strategies)}…")

                try:
                    with suppress_http_warnings():
                        with yt_dlp.YoutubeDL(attempt_opts) as ydl:
                            info = ydl.extract_info(self.url, download=True)

                            if not info:
                                raise Exception("Could not extract video information")

                            expected_filename = ydl.prepare_filename(info)
                            output_file = Path(expected_filename)

                            if output_file.exists() and output_file.stat().st_size > 0:
                                file_size = output_file.stat().st_size
                                self.emitter.status.emit(f"Download complete! ({file_size / 1024 / 1024:.1f} MB)")
                                success = True
                                break
                            else:
                                for ext in ['mp3', 'wav', 'flac', 'mp4', 'mkv', 'webm']:
                                    converted = output_file.with_suffix(f'.{ext}')
                                    if converted.exists() and converted.stat().st_size > 0:
                                        file_size = converted.stat().st_size
                                        self.emitter.status.emit(f"Download complete! ({file_size / 1024 / 1024:.1f} MB)")
                                        success = True
                                        break
                                if success:
                                    break
                                raise Exception("Downloaded file not found after completion")

                except StopIteration:
                    raise
                except Exception as e:
                    last_error = str(e)
                    continue  # try next strategy

            if not success:
                raise Exception(last_error or "All download strategies failed")

            self.finished.emit(True)

        except StopIteration:
            self.emitter.progress.emit(0)
            self.finished.emit(False)

        except Exception as e:
            error_msg = str(e)
            
            # Provide helpful error messages for common issues
            if "Requested format is not available" in error_msg or "Only images are available" in error_msg or "No video formats found" in error_msg:
                self.error.emit(
                    "YouTube Format / PO Token Error\n\n"
                    "YouTube is blocking format access. Try these fixes in order:\n\n"
                    "STEP 1 — Load fresh cookies (easiest fix):\n"
                    "1. Log into YouTube in your browser\n"
                    "2. Export cookies with the 'Get cookies.txt LOCALLY' extension\n"
                    "3. Click 'Select Cookies File' and load them\n"
                    "4. Try again\n\n"
                    "STEP 2 — Install PO Token plugin:\n"
                    "   pip install bgutil-ytdlp-pot-provider\n"
                    "   (also requires Node.js from https://nodejs.org/)\n\n"
                    "STEP 3 — Update yt-dlp:\n"
                    "   pip install --upgrade yt-dlp\n\n"
                    f"Technical: {error_msg[:150]}..."
                )
            elif "403" in error_msg or "forbidden" in error_msg.lower():
                self.error.emit(
                    "YouTube Download Blocked (403 Forbidden)\n\n"
                    "YouTube is blocking this download due to their anti-bot protection.\n\n"
                    "SOLUTION: Install Node.js to solve YouTube's challenges\n\n"
                    "1. Download Node.js from: https://nodejs.org/\n"
                    "2. Install it (keep default settings)\n"
                    "3. Restart Download of Death\n"
                    "4. Try download again\n\n"
                    "Alternative: Some videos may not be downloadable due to restrictions.\n\n"
                    f"Technical details: {error_msg[:200]}..."
                )
            elif "empty" in error_msg.lower():
                self.error.emit(
                    "Empty Download Error\n\n"
                    "Possible causes:\n"
                    "• Video is region-locked or geo-restricted\n"
                    "• Video requires login/cookies (click 'Select Cookies File')\n"
                    "• Video is private or deleted\n"
                    "• Network connection interrupted\n\n"
                    f"Technical details: {error_msg}"
                )
            elif "429" in error_msg or "too many requests" in error_msg.lower():
                self.error.emit(
                    "Rate Limited\n\n"
                    "YouTube is throttling requests. Try:\n"
                    "• Wait a few minutes and try again\n"
                    "• Use cookies file (click 'Select Cookies File')\n"
                    "• Check your internet connection\n\n"
                    f"Technical details: {error_msg}"
                )
            else:
                self.error.emit(error_msg)


# =============================================================================
# UPDATE WORKER
# =============================================================================

class UpdateWorker(QThread):
    output  = pyqtSignal(str)   # live pip output lines
    finished = pyqtSignal(bool, str)  # success, version string

    def run(self):
        import subprocess, importlib.metadata
        try:
            proc = subprocess.Popen(
                [sys.executable, "-m", "pip", "install", "--upgrade", "yt-dlp"],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            for line in proc.stdout:
                self.output.emit(line.rstrip())
            proc.wait()
            if proc.returncode == 0:
                # Reload the installed version string
                try:
                    import importlib
                    import yt_dlp as _ytdlp_mod
                    importlib.reload(_ytdlp_mod)
                    ver = importlib.metadata.version("yt-dlp")
                except Exception:
                    ver = "unknown"
                self.finished.emit(True, ver)
            else:
                self.finished.emit(False, "pip exited with an error — check the log above.")
        except Exception as e:
            self.finished.emit(False, str(e))


# =============================================================================
# MAIN WINDOW
# =============================================================================

class DownloadOfDeath(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(760, 520)
        self.setFont(QFont("Courier", 10))

        self.queue = []
        self.output_dir = None
        self.cookies_file = None
        self.browser_cookies = None  # (browser, None, None, None) tuple for yt-dlp
        self.worker = None
        self.emitter = ProgressEmitter()

        self._build_ui()
        self._connect()

    def _build_ui(self):
        self.url_input = QLineEdit()
        self.add_btn = QPushButton("Add to Queue")
        self.queue_list = QListWidget()

        self.format_box = QComboBox()
        self.format_box.addItems(["MP4", "MKV", "MP3", "WAV", "FLAC"])

        self.output_btn = QPushButton("Select Output Folder")
        self.output_label = QLabel("No folder selected")
        
        self.cookies_btn = QPushButton("Select Cookies File (Optional)")
        self.cookies_label = QLabel("No cookies file selected")
        self.cookies_label.setStyleSheet("color: #006400; font-style: italic;")

        # Browser cookies dropdown
        browser_row = QHBoxLayout()
        self.browser_label = QLabel("Or use browser cookies:")
        self.browser_box = QComboBox()
        self.browser_box.addItems(["None", "Firefox", "Chrome", "Edge", "Chromium", "Brave", "Safari"])
        self.browser_use_btn = QPushButton("Use Browser")
        self.browser_status = QLabel("")
        self.browser_status.setStyleSheet("color: #006400; font-style: italic;")
        browser_row.addWidget(self.browser_label)
        browser_row.addWidget(self.browser_box)
        browser_row.addWidget(self.browser_use_btn)

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.status = QLabel("Idle")

        self.start_btn = QPushButton("Start Queue")
        self.pause_btn = QPushButton("Pause")
        self.resume_btn = QPushButton("Resume")
        self.cancel_btn = QPushButton("Cancel Current")
        self.help_btn = QPushButton("Help: Bot Detection")
        self.update_btn = QPushButton("Update yt-dlp")

        # Show current yt-dlp version
        try:
            import importlib.metadata as _im
            _ver = _im.version("yt-dlp")
        except Exception:
            _ver = "unknown"
        self.ytdlp_version_label = QLabel(f"yt-dlp version: {_ver}")
        self.ytdlp_version_label.setStyleSheet("color: #006400; font-style: italic;")

        layout = QVBoxLayout(self)
        layout.addWidget(self.url_input)
        layout.addWidget(self.add_btn)
        layout.addWidget(self.queue_list)
        layout.addWidget(self.format_box)
        layout.addWidget(self.output_btn)
        layout.addWidget(self.output_label)
        layout.addWidget(self.cookies_btn)
        layout.addWidget(self.cookies_label)
        layout.addLayout(browser_row)
        layout.addWidget(self.browser_status)
        layout.addWidget(self.progress)
        layout.addWidget(self.status)

        row = QHBoxLayout()
        for b in (self.start_btn, self.pause_btn, self.resume_btn, self.cancel_btn):
            row.addWidget(b)
        layout.addLayout(row)
        layout.addWidget(self.help_btn)

        update_row = QHBoxLayout()
        update_row.addWidget(self.update_btn)
        update_row.addWidget(self.ytdlp_version_label)
        layout.addLayout(update_row)

    def _connect(self):
        self.add_btn.clicked.connect(self.add_url)
        self.output_btn.clicked.connect(self.pick_folder)
        self.cookies_btn.clicked.connect(self.pick_cookies)
        self.browser_use_btn.clicked.connect(self.use_browser_cookies)
        self.start_btn.clicked.connect(self.start_queue)
        self.help_btn.clicked.connect(self.show_help)

        self.pause_btn.clicked.connect(lambda: self.worker.pause() if self.worker else None)
        self.resume_btn.clicked.connect(lambda: self.worker.resume() if self.worker else None)
        self.cancel_btn.clicked.connect(lambda: self.worker.cancel() if self.worker else None)

        self.emitter.progress.connect(self.progress.setValue)
        self.emitter.status.connect(self.status.setText)
        self.update_btn.clicked.connect(self.update_ytdlp)

    def add_url(self):
        if self.url_input.text():
            self.queue.append(self.url_input.text())
            self.queue_list.addItem(self.url_input.text())
            self.url_input.clear()

    def pick_folder(self):
        f = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if f:
            self.output_dir = Path(f)
            self.output_label.setText(str(self.output_dir))
    
    def use_browser_cookies(self):
        browser = self.browser_box.currentText().lower()
        if browser == "none":
            self.browser_cookies = None
            self.browser_status.setText("")
            return
        self.browser_cookies = (browser, None, None, None)
        self.cookies_file = None
        self.cookies_label.setText("No cookies file selected")
        self.cookies_label.setStyleSheet("color: #006400; font-style: italic;")
        self.browser_status.setText(f"Using {browser.title()} cookies")
        self.browser_status.setStyleSheet("color: #00dc00;")

    def pick_cookies(self):
        f, _ = QFileDialog.getOpenFileName(
            self,
            "Select Cookies File",
            str(Path.home()),
            "Text Files (*.txt);;All Files (*.*)"
        )
        if f:
            self.cookies_file = Path(f)
            self.browser_cookies = None  # file takes priority; clear browser
            self.browser_status.setText("")
            self.cookies_label.setText(str(self.cookies_file))
            self.cookies_label.setStyleSheet("color: #00dc00;")
            QMessageBox.information(
                self,
                APP_NAME,
                "Cookies file loaded! This should help bypass YouTube's bot detection."
            )
    
    def show_help(self):
        help_text = """<h3>YouTube Bot Detection Fix</h3>
        
<p>If you see "Sign in to confirm you're not a bot" errors:</p>

<h4>Quick Fix:</h4>
<ol>
<li><b>Install browser extension:</b><br>
   • Chrome/Edge: "Get cookies.txt LOCALLY"<br>
   • Firefox: "cookies.txt"</li>

<li><b>Export cookies:</b><br>
   • Go to youtube.com (logged in)<br>
   • Click extension icon<br>
   • Click "Export"<br>
   • Save as youtube_cookies.txt</li>

<li><b>Load in app:</b><br>
   • Click "Select Cookies File"<br>
   • Choose your saved cookies file<br>
   • Try download again!</li>
</ol>

<h4>Important:</h4>
<p>⚠️ Keep cookies file private - it's like your password!<br>
⚠️ Re-export every few months when cookies expire</p>

<h4>Extension Links:</h4>
<p>Chrome: chrome.google.com/webstore<br>
   Search: "Get cookies.txt LOCALLY"</p>
<p>Firefox: addons.mozilla.org<br>
   Search: "cookies.txt"</p>
"""
        msg = QMessageBox(self)
        msg.setWindowTitle(f"{APP_NAME} - Help")
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setText(help_text)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg.exec()

    def update_ytdlp(self):
        """Run pip install --upgrade yt-dlp in a background thread with live output."""
        self.update_btn.setEnabled(False)
        self.update_btn.setText("Updating...")

        # Build a proper modal QDialog — no QMessageBox hacks that spawn new windows
        dlg = QDialog(self)
        dlg.setWindowTitle(f"{APP_NAME} - Updating yt-dlp")
        dlg.setMinimumWidth(520)
        dlg.setModal(True)

        layout = QVBoxLayout(dlg)

        lbl = QLabel("Updating yt-dlp via pip...\n\nPlease wait.")
        lbl.setFont(QFont("Courier", 10))
        layout.addWidget(lbl)

        log = QTextEdit()
        log.setReadOnly(True)
        log.setFont(QFont("Courier", 9))
        log.setFixedHeight(200)
        layout.addWidget(log)

        btn_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
        btn_box.button(QDialogButtonBox.StandardButton.Close).setEnabled(False)
        btn_box.rejected.connect(dlg.accept)
        layout.addWidget(btn_box)

        self._update_log = log
        self._update_dlg = dlg
        self._update_lbl = lbl
        self._update_btn_box = btn_box

        self._updater = UpdateWorker()
        self._updater.output.connect(self._on_update_output)
        self._updater.finished.connect(self._on_update_finished)
        self._updater.start()

        dlg.exec()  # blocks only this dialog, not the main window

    def _on_update_output(self, line: str):
        self._update_log.append(line)

    def _on_update_finished(self, ok: bool, detail: str):
        self.update_btn.setEnabled(True)
        self.update_btn.setText("Update yt-dlp")
        self._update_btn_box.button(QDialogButtonBox.StandardButton.Close).setEnabled(True)

        if ok:
            self.ytdlp_version_label.setText(f"yt-dlp version: {detail}")
            self.ytdlp_version_label.setStyleSheet("color: #00dc00; font-style: italic;")
            self._update_lbl.setText(
                f"yt-dlp updated successfully!\n\n"
                f"Installed version: {detail}\n\n"
                "Restart the app to use the new version."
            )
        else:
            self._update_lbl.setText(
                f"Update failed:\n\n{detail}\n\n"
                "Try running manually:  pip install --upgrade yt-dlp"
            )

    def start_queue(self):
        if not self.queue or not self.output_dir:
            QMessageBox.warning(self, APP_NAME, "Queue empty or output folder missing.")
            return
        self.start_btn.setEnabled(False)
        self.status.setText("Starting queue…")
        self._next()

    def _next(self):
        if not self.queue:
            self.status.setText("Queue complete.")
            self.start_btn.setEnabled(True)
            return

        url = self.queue.pop(0)
        self.queue_list.takeItem(0)
        self.progress.setValue(0)
        self.status.setText(f"Preparing: {url}")

        self.worker = DownloadWorker(
            url,
            self.output_dir,
            self.format_box.currentText(),
            self.emitter,
            self.cookies_file,
            self.browser_cookies,
        )
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()
    
    def _on_error(self, error_msg):
        # Proxy connection refused / unreachable
        if ("Unable to connect to proxy" in error_msg or
                "ProxyError" in error_msg or
                ("connect to proxy" in error_msg.lower() and "10061" in error_msg)):
            QMessageBox.critical(
                self,
                APP_NAME,
                "Proxy Connection Error\n\n"
                "yt-dlp is trying to reach a proxy that isn't running "
                "(usually 127.0.0.1:1933 — Proxies of Death or a VPN).\n\n"
                "TO FIX — choose one:\n\n"
                "1. Start your local proxy / VPN before downloading, OR\n"
                "2. Clear the proxy env vars in your shell:\n"
                "     set HTTPS_PROXY=\n"
                "     set HTTP_PROXY=\n"
                "   then restart Download of Death, OR\n"
                "3. Just retry — the app will automatically clear those\n"
                "   env vars before the next attempt.\n\n"
                f"Technical details:\n{error_msg[:300]}"
            )
            return

        # Check if it's a bot detection error
        if "Sign in to confirm you're not a bot" in error_msg or "LOGIN_REQUIRED" in error_msg:
            # Check if we have cookies loaded but they're invalid
            if self.cookies_file:
                QMessageBox.critical(
                    self, 
                    APP_NAME,
                    "Cookies File Expired!\n\n"
                    "Your cookies file is loaded but no longer valid.\n"
                    "YouTube rotated your cookies for security.\n\n"
                    "TO FIX:\n\n"
                    "1. Go to YouTube in your browser (make sure you're logged in)\n"
                    "2. Click your cookies export extension\n"
                    "3. Export cookies again (overwrites old file)\n"
                    "4. In Download of Death, click 'Select Cookies File'\n"
                    "5. Choose the NEW cookies file\n"
                    "6. Try download again\n\n"
                    "Note: Cookies expire regularly - you may need to\n"
                    "re-export them every few weeks.\n\n"
                    f"Technical error:\n{error_msg[:200]}..."
                )
            else:
                QMessageBox.critical(
                    self, 
                    APP_NAME,
                    "YouTube Bot Detection Error\n\n"
                    "YouTube has blocked this download. To fix:\n\n"
                    "1. Click 'Select Cookies File'\n"
                    "2. Export cookies from your browser using an extension\n"
                    "   (search for 'cookies.txt' extension for your browser)\n"
                    "3. Select the exported cookies file\n"
                    "4. Try downloading again\n\n"
                    f"Technical error:\n{error_msg[:200]}..."
                )
        elif "cookies" in error_msg.lower() and "invalid" in error_msg.lower():
            QMessageBox.critical(
                self,
                APP_NAME,
                "Invalid Cookies File\n\n"
                "The cookies file format is incorrect or corrupted.\n\n"
                "TO FIX:\n\n"
                "1. Re-export cookies using the browser extension\n"
                "2. Make sure you export from youtube.com (not google.com)\n"
                "3. The file should be plain text, not JSON\n"
                "4. Try selecting the new cookies file\n\n"
                f"Technical error:\n{error_msg[:200]}..."
            )
        else:
            QMessageBox.critical(self, APP_NAME, f"Download Error:\n\n{error_msg}")
    

    def _on_finished(self, success: bool):
        if success:
            self.status.setText("Download completed. Moving to next item…")
        else:
            self.status.setText("Download cancelled. Skipping to next item…")
        self._next()


# =============================================================================
# PLUGIN LOADER (frozen PyInstaller bundle support)
# =============================================================================

def _load_ytdlp_plugins():
    """Force-load yt-dlp plugins when running as a frozen PyInstaller bundle.
    In normal script execution, plugins load automatically via entry points.
    """
    if not getattr(sys, 'frozen', False):
        return
    try:
        import yt_dlp.extractor
        import yt_dlp.postprocessor
        yt_dlp.extractor.gen_extractors()
    except Exception:
        pass
    try:
        import bgutil_ytdlp_pot_provider  # noqa: F401
    except ImportError:
        pass  # Plugin not installed — cookies fallback still works


def _bootstrap_ejs():
    """Silently download the yt-dlp JS challenge solver script on first run.
    This is the equivalent of: yt-dlp --remote-components ejs:github
    Runs in a background thread so it doesn't block the UI.
    """
    def _fetch():
        try:
            import yt_dlp
            opts = {
                "quiet": True,
                "no_warnings": True,
                "simulate": True,
                "skip_download": True,
                "js_runtimes": {"node": {}},
                "remote_components": ["ejs:github"],
            }
            # Use a short benign video just to trigger the component download
            with yt_dlp.YoutubeDL(opts) as ydl:
                ydl.download(["https://www.youtube.com/watch?v=dQw4w9WgXcQ"])
        except Exception:
            pass  # Non-fatal — downloads still work without it for most videos

    t = threading.Thread(target=_fetch, daemon=True)
    t.start()


# =============================================================================
# ENTRY
# =============================================================================

def main():
    _load_ytdlp_plugins()
    _bootstrap_ejs()  # Silently fetch JS challenge solver in background

    # On Windows, set application ID for proper taskbar icon grouping
    if sys.platform == "win32":
        try:
            import ctypes
            # Set application user model ID for taskbar icon
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                'DeathsHeadSoftware.DownloadOfDeath.1.0'
            )
        except:
            pass
    
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    
    # Set application icon for taskbar - MUST be set before creating windows
    icon_path = get_icon_path()
    if icon_path:
        icon = QIcon(icon_path)
        if not icon.isNull():
            app.setWindowIcon(icon)
            # On Windows, also set as the default icon
            if sys.platform == "win32":
                QApplication.setWindowIcon(icon)
        else:
            print(f"Warning: Could not load icon from {icon_path}")
    else:
        print("Warning: Icon file not found")
    
    apply_dark_palette(app)

    splash = create_splash("Initializing Download Engine…")
    splash.show()
    app.processEvents()
    time.sleep(5.5)

    win = DownloadOfDeath()
    
    # Set window icon as well
    if icon_path:
        icon = QIcon(icon_path)
        if not icon.isNull():
            win.setWindowIcon(icon)
    
    win.show()
    splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
