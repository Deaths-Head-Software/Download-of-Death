from __future__ import annotations

import sys
import os
import time
import shutil
from pathlib import Path
import threading

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QObject
from PyQt6.QtGui import (
    QFont, QPainter, QPixmap, QColor, QIcon,
    QGuiApplication, QPalette
)
from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QFileDialog, QMessageBox,
    QComboBox, QProgressBar, QListWidget, QTextEdit,
    QSplashScreen
)

import yt_dlp

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    try:
        # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    
    return os.path.join(base_path, relative_path)


def find_ffmpeg():
    """Find FFmpeg and ffprobe in local directory, bundled resources, or system PATH"""
    
    # 1. Check current directory first (for portable installations)
    current_dir = Path.cwd()
    if sys.platform == "win32":
        local_ffmpeg = current_dir / "ffmpeg.exe"
        local_ffprobe = current_dir / "ffprobe.exe"
    else:
        local_ffmpeg = current_dir / "ffmpeg"
        local_ffprobe = current_dir / "ffprobe"
    
    if local_ffmpeg.exists() and local_ffprobe.exists():
        print(f"Using local FFmpeg from: {current_dir}")
        return str(current_dir)
    
    # 2. Check bundled FFmpeg (for PyInstaller)
    if sys.platform == "win32":
        bundled_ffmpeg = Path(resource_path("ffmpeg.exe"))
        bundled_ffprobe = Path(resource_path("ffprobe.exe"))
    else:
        bundled_ffmpeg = Path(resource_path("ffmpeg"))
        bundled_ffprobe = Path(resource_path("ffprobe"))
    
    if bundled_ffmpeg.exists() and bundled_ffprobe.exists():
        print(f"Using bundled FFmpeg from: {bundled_ffmpeg.parent}")
        return str(bundled_ffmpeg.parent)
    
    # 3. Check system PATH
    ffmpeg_cmd = "ffmpeg.exe" if sys.platform == "win32" else "ffmpeg"
    ffprobe_cmd = "ffprobe.exe" if sys.platform == "win32" else "ffprobe"
    
    system_ffmpeg = shutil.which(ffmpeg_cmd)
    system_ffprobe = shutil.which(ffprobe_cmd)
    
    if system_ffmpeg and system_ffprobe:
        # Return the directory containing both executables
        ffmpeg_dir = str(Path(system_ffmpeg).parent)
        print(f"Using system FFmpeg from: {ffmpeg_dir}")
        return ffmpeg_dir
    
    print("WARNING: FFmpeg/ffprobe not found!")
    print("Run: python3 setup.py")
    return None


APP_NAME = "Download of Death"
ORG_NAME = "Death's Head Software"
HISTORY_FILE = Path.home() / ".download_of_death_history.log"


# =============================================================================
# PALETTE
# =============================================================================

def apply_light_palette(app):
    p = QPalette()
    window = QColor(245, 245, 245)
    base = QColor(255, 255, 255)
    button = QColor(235, 235, 235)
    text = QColor(20, 20, 20)
    highlight = QColor(30, 144, 255)

    for g in (QPalette.ColorGroup.Active, QPalette.ColorGroup.Inactive):
        p.setColor(g, QPalette.ColorRole.Window, window)
        p.setColor(g, QPalette.ColorRole.WindowText, text)
        p.setColor(g, QPalette.ColorRole.Base, base)
        p.setColor(g, QPalette.ColorRole.Text, text)
        p.setColor(g, QPalette.ColorRole.Button, button)
        p.setColor(g, QPalette.ColorRole.ButtonText, text)
        p.setColor(g, QPalette.ColorRole.Highlight, highlight)
        p.setColor(g, QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))

    app.setPalette(p)


# =============================================================================
# SPLASH
# =============================================================================

def create_splash(message: str):
    splash_path = resource_path("splash.png")
    
    print(f"Looking for splash screen at: {splash_path}")
    print(f"File exists: {Path(splash_path).exists()}")
    
    if Path(splash_path).exists():
        print("Loading splash.png...")
        pixmap = QPixmap(str(splash_path)).scaled(
            800, 600,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
        print(f"Splash image loaded: {pixmap.width()}x{pixmap.height()}")
    else:
        print("WARNING: splash.png not found! Creating blank splash...")
        pixmap = QPixmap(800, 600)
        pixmap.fill(QColor(255, 255, 255))

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    painter.setPen(QColor("white"))
    painter.setFont(QFont("Courier", 34, QFont.Weight.Bold))
    painter.drawText(pixmap.rect().adjusted(0, 40, 0, -480), Qt.AlignmentFlag.AlignCenter, APP_NAME)

    painter.setFont(QFont("Courier", 12))
    painter.drawText(pixmap.rect().adjusted(0, 480, 0, -90), Qt.AlignmentFlag.AlignCenter, ORG_NAME)

    painter.setFont(QFont("Courier", 11))
    painter.drawText(pixmap.rect().adjusted(0, 520, 0, 0), Qt.AlignmentFlag.AlignCenter, message)

    painter.end()
    print("✓ Text overlay added")
    
    # Create splash with multiple window flags to ensure visibility
    splash = QSplashScreen(
        pixmap, 
        Qt.WindowType.SplashScreen | 
        Qt.WindowType.WindowStaysOnTopHint |
        Qt.WindowType.FramelessWindowHint
    )
    
    return splash


# =============================================================================
# PROGRESS EMITTER
# =============================================================================

class ProgressEmitter(QObject):
    progress = pyqtSignal(int)
    status = pyqtSignal(str)


# =============================================================================
# DOWNLOAD WORKER
# =============================================================================

class DownloadWorker(QThread):
    finished = pyqtSignal(bool)  # True = normal, False = cancelled
    error = pyqtSignal(str)

    def __init__(self, url, out_dir, fmt, emitter, ffmpeg_path=None, cookie_file=None):
        super().__init__()
        self.url = url
        self.out_dir = out_dir
        self.fmt = fmt
        self.emitter = emitter
        self.ffmpeg_path = ffmpeg_path
        self.cookie_file = cookie_file

        self._pause = threading.Event()
        self._pause.set()
        self._cancelled = False

    def pause(self):
        self.emitter.status.emit("Paused")
        self._pause.clear()

    def resume(self):
        self.emitter.status.emit("Resuming download…")
        self._pause.set()

    def cancel(self):
        self._cancelled = True
        self._pause.set()
        self.emitter.status.emit("Cancelling current download…")

    def run(self):
        try:
            # Debug: Show FFmpeg configuration
            if self.ffmpeg_path:
                self.emitter.status.emit(f"Using FFmpeg from: {self.ffmpeg_path}")
            else:
                self.emitter.status.emit("WARNING: No FFmpeg path configured!")
            
            def hook(d):
                while not self._pause.is_set():
                    time.sleep(0.2)

                if self._cancelled:
                    raise StopIteration

                if d["status"] == "downloading":
                    downloaded = d.get("downloaded_bytes", 0)
                    total = d.get("total_bytes") or d.get("total_bytes_estimate", 1)
                    pct = int((downloaded / max(total, 1)) * 100)
                    self.emitter.progress.emit(pct)
                    self.emitter.status.emit(f"Downloading… {pct}%")

                elif d["status"] == "finished":
                    self.emitter.progress.emit(100)
                    self.emitter.status.emit("Finalizing file…")

            opts = {
                "outtmpl": str(self.out_dir / "%(title)s.%(ext)s"),
                "progress_hooks": [hook],
                "quiet": False,
                "no_warnings": False,
                "verbose": True,  # Enable verbose output for debugging
                "noplaylist": True,
                "force_ipv4": True,
            }

            # Add FFmpeg location if available (ffmpeg_path is the directory)
            if self.ffmpeg_path:
                opts["ffmpeg_location"] = self.ffmpeg_path
                self.emitter.status.emit(f"FFmpeg location set to: {self.ffmpeg_path}")
            else:
                self.emitter.status.emit("WARNING: FFmpeg location not set!")
            
            # Add cookies file if provided (for authentication/age-restricted videos)
            if self.cookie_file:
                opts["cookiefile"] = str(self.cookie_file)
                self.emitter.status.emit(f"Using cookies from: {self.cookie_file.name}")

            if self.fmt in ("MP3", "WAV", "FLAC"):
                opts.update({
                      "format": "bestaudio/best",
                      "postprocessors": [{
                            "key": "FFmpegExtractAudio",
                            "preferredcodec": self.fmt.lower(),
                            "preferredquality": "0",
                     }],
                })

            else:
                opts.update({"format": "bv*+ba/b", "merge_output_format": self.fmt.lower()})

            with yt_dlp.YoutubeDL(opts) as ydl:
                ydl.download([self.url])

            self.finished.emit(True)

        except StopIteration:
            self.emitter.progress.emit(0)
            self.finished.emit(False)

        except Exception as e:
            self.error.emit(str(e))


# =============================================================================
# MAIN WINDOW
# =============================================================================

class DownloadOfDeath(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(760, 520)
        self.setFont(QFont("Courier", 10))
        
        # Set window icon
        self._set_icon()

        self.queue = []
        self.output_dir = None
        self.cookie_file = None
        self.worker = None
        self.emitter = ProgressEmitter()
        self.ffmpeg_path = None

        self._build_ui()
        self._connect()
        self._check_ffmpeg()

    def _set_icon(self):
        """Set window icon, trying .png first (preferred on Linux), then .ico"""
        # Try .png first (preferred on Linux)
        png_path = resource_path("icon.png")
        if Path(png_path).exists():
            self.setWindowIcon(QIcon(png_path))
            return
        
        # Fall back to .ico (Windows format but works on Linux too)
        ico_path = resource_path("icon.ico")
        if Path(ico_path).exists():
            self.setWindowIcon(QIcon(ico_path))

    def _check_ffmpeg(self):
        """Check for FFmpeg availability"""
        self.ffmpeg_path = find_ffmpeg()
        
        if self.ffmpeg_path:
            # FFmpeg found - show in status (ffmpeg_path is now the directory)
            msg = f"Ready | FFmpeg: {self.ffmpeg_path} ✓"
            self.status.setText(msg)
            print(f"FFmpeg detected at: {self.ffmpeg_path}")
            print(f"  - {self.ffmpeg_path}/ffmpeg")
            print(f"  - {self.ffmpeg_path}/ffprobe")
        else:
            # FFmpeg not found - show warning in status
            self.status.setText("Ready | FFmpeg/ffprobe NOT FOUND ✗")
            print("WARNING: FFmpeg and/or ffprobe not found in PATH")

    def _build_ui(self):
        self.url_input = QLineEdit()
        self.url_input.setPlaceholderText("Enter video URL (YouTube, etc.)")
        self.add_btn = QPushButton("Add to Queue")
        self.queue_list = QListWidget()

        self.format_box = QComboBox()
        self.format_box.addItems(["MP4", "MKV", "MP3", "WAV", "FLAC"])

        self.output_btn = QPushButton("Select Output Folder")
        self.output_label = QLabel("No folder selected")
        
        # Cookie file selection
        self.cookie_btn = QPushButton("Select Cookies File (Optional)")
        self.cookie_label = QLabel("No cookies file selected")

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.status = QLabel("Idle")

        self.start_btn = QPushButton("Start Queue")
        self.pause_btn = QPushButton("Pause")
        self.resume_btn = QPushButton("Resume")
        self.cancel_btn = QPushButton("Cancel Current")

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Video URL:"))
        layout.addWidget(self.url_input)
        layout.addWidget(self.add_btn)
        layout.addWidget(QLabel("Download Queue:"))
        layout.addWidget(self.queue_list)
        layout.addWidget(QLabel("Output Format:"))
        layout.addWidget(self.format_box)
        layout.addWidget(self.output_btn)
        layout.addWidget(self.output_label)
        layout.addWidget(QLabel("Cookies File (for private/age-restricted videos):"))
        layout.addWidget(self.cookie_btn)
        layout.addWidget(self.cookie_label)
        layout.addWidget(QLabel("Progress:"))
        layout.addWidget(self.progress)
        layout.addWidget(self.status)

        row = QHBoxLayout()
        for b in (self.start_btn, self.pause_btn, self.resume_btn, self.cancel_btn):
            row.addWidget(b)
        layout.addLayout(row)

    def _connect(self):
        self.add_btn.clicked.connect(self.add_url)
        self.output_btn.clicked.connect(self.pick_folder)
        self.cookie_btn.clicked.connect(self.pick_cookie)
        self.start_btn.clicked.connect(self.start_queue)

        self.pause_btn.clicked.connect(lambda: self.worker.pause() if self.worker else None)
        self.resume_btn.clicked.connect(lambda: self.worker.resume() if self.worker else None)
        self.cancel_btn.clicked.connect(lambda: self.worker.cancel() if self.worker else None)

        self.emitter.progress.connect(self.progress.setValue)
        self.emitter.status.connect(self.status.setText)

    def add_url(self):
        url = self.url_input.text().strip()
        if url:
            self.queue.append(url)
            self.queue_list.addItem(url)
            self.url_input.clear()

    def pick_folder(self):
        f = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if f:
            self.output_dir = Path(f)
            self.output_label.setText(str(self.output_dir))
    
    def pick_cookie(self):
        f, _ = QFileDialog.getOpenFileName(
            self, 
            "Select Cookies File",
            "",
            "Text Files (*.txt);;All Files (*)"
        )
        if f:
            self.cookie_file = Path(f)
            self.cookie_label.setText(f"Cookies: {self.cookie_file.name}")
            self.status.setText(f"Cookies file loaded: {self.cookie_file.name}")

    def start_queue(self):
        if not self.queue:
            QMessageBox.warning(self, APP_NAME, "Queue is empty. Add URLs first.")
            return
            
        if not self.output_dir:
            QMessageBox.warning(self, APP_NAME, "Please select an output folder.")
            return
        
        # Check if FFmpeg is needed for selected format
        fmt = self.format_box.currentText()
        if fmt in ("MP3", "WAV", "FLAC") and not self.ffmpeg_path:
            if sys.platform == "linux":
                install_cmd = "sudo apt install ffmpeg"
            elif sys.platform == "darwin":
                install_cmd = "brew install ffmpeg"
            else:
                install_cmd = "Download from ffmpeg.org"
            
            reply = QMessageBox.question(
                self,
                "FFmpeg Required",
                f"{fmt} format requires FFmpeg for audio extraction.\n\n"
                f"FFmpeg was not found on your system.\n\n"
                f"To install FFmpeg:\n{install_cmd}\n\n"
                "Continue anyway? (Download will fail)",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.No:
                return
        
        self.start_btn.setEnabled(False)
        self.status.setText("Starting queue…")
        self._next()

    def _next(self):
        if not self.queue:
            self.status.setText("Queue complete.")
            self.start_btn.setEnabled(True)
            return

        url = self.queue.pop(0)
        self.queue_list.takeItem(0)
        self.progress.setValue(0)
        self.status.setText(f"Preparing: {url}")

        self.worker = DownloadWorker(
            url, 
            self.output_dir, 
            self.format_box.currentText(), 
            self.emitter,
            self.ffmpeg_path,
            self.cookie_file
        )
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()

    def _on_error(self, message: str):
        """Handle download errors"""
        # Show full error message
        error_msg = f"Download failed:\n\n{message}"
        
        # Check for common FFmpeg errors
        if "ffmpeg" in message.lower() or "postprocessor" in message.lower():
            error_msg += "\n\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            error_msg += "\n\nThis error is related to FFmpeg."
            
            if not self.ffmpeg_path:
                error_msg += "\n\nFFmpeg was not found on your system."
                if sys.platform == "linux":
                    error_msg += "\n\nInstall with:\nsudo apt install ffmpeg"
                elif sys.platform == "darwin":
                    error_msg += "\n\nInstall with:\nbrew install ffmpeg"
            else:
                error_msg += f"\n\nFFmpeg location: {self.ffmpeg_path}"
                error_msg += "\n\nTry updating yt-dlp:\npip install --upgrade yt-dlp --break-system-packages"
        
        QMessageBox.critical(self, APP_NAME, error_msg)
        self._next()  # Continue with next item in queue

    def _on_finished(self, success: bool):
        if success:
            self.status.setText("Download completed. Moving to next item…")
        else:
            self.status.setText("Download cancelled. Skipping to next item…")
        self._next()


# =============================================================================
# ENTRY
# =============================================================================

def main():
    app = QApplication(sys.argv)
    apply_light_palette(app)

    # Create splash screen
    splash = create_splash("Initializing Download Engine…")
    
    # Get screen geometry and center the splash
    screen = app.primaryScreen().geometry()
    splash_rect = splash.geometry()
    x = (screen.width() - splash_rect.width()) // 2
    y = (screen.height() - splash_rect.height()) // 2
    splash.move(x, y)
    
    # Force it to show
    splash.show()
    splash.raise_()  # Bring to front
    splash.activateWindow()  # Make it active
    splash.setFocus()  # Give it focus
    app.processEvents()
    
    print("Splash screen displayed. Waiting 5.5 seconds...")
    
    # Keep processing events during the wait
    for i in range(55):  # 55 * 0.1 = 5.5 seconds
        time.sleep(0.1)
        app.processEvents()  # Keep refreshing
    
    print("Opening main window...")

    win = DownloadOfDeath()
    win.show()
    splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
