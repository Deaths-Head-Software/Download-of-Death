# YouTube PO Token Provider - The Real Solution

## What This Is

The `bgutil-ytdlp-pot-provider` is a plugin for yt-dlp that **automatically generates PO Tokens** needed for YouTube downloads. This is the solution to YouTube's latest anti-bot protection.

GitHub: https://github.com/Brainicism/bgutil-ytdlp-pot-provider

## Why You Need This

YouTube's "PO Token" (Proof of Origin) protection is blocking most downloads. This plugin:
- ✓ Generates valid PO Tokens automatically
- ✓ Works with the latest yt-dlp
- ✓ No manual token extraction needed
- ✓ Fixes "No video formats found" errors
- ✓ Fixes "Requested format is not available" errors

## Installation

### Quick Install (Recommended)

**Windows:**
```cmd
pip install bgutil-ytdlp-pot-provider
```

**macOS/Linux:**
```bash
pip3 install bgutil-ytdlp-pot-provider
```

### What Gets Installed

The plugin installs to yt-dlp's plugin directory:
- **Windows:** `%APPDATA%\yt-dlp\plugins\`
- **macOS/Linux:** `~/.yt-dlp/plugins/`

It runs automatically - no configuration needed!

## Verify Installation

```bash
yt-dlp --version
```

Look for output mentioning the plugin, or test a download:

```bash
yt-dlp -v "https://www.youtube.com/watch?v=jNQXAC9IVRw"
```

If verbose output shows PO Token generation, it's working!

## Using With Download of Death

### Option 1: Install Plugin, Then Use App

1. **Install the plugin:**
   ```cmd
   pip install bgutil-ytdlp-pot-provider
   ```

2. **Restart Download of Death**

3. **Try your download** - should work now!

The plugin works automatically with yt-dlp, so Download of Death will use it.

### Option 2: Run From Source

If running the Python script directly:

```bash
# Install plugin
pip install bgutil-ytdlp-pot-provider

# Run app
python download_of_death.py
```

Works immediately!

### Option 3: Rebuild Executable With Plugin

For the **bundled executable** to use the plugin, you need to rebuild:

**Windows:**
```cmd
# Install plugin first
pip install bgutil-ytdlp-pot-provider

# Then rebuild
build_windows.bat
```

**macOS:**
```bash
# Install plugin first
pip3 install bgutil-ytdlp-pot-provider

# Then rebuild
./build_macos.sh
```

PyInstaller will bundle the plugin automatically if it's installed.

## Testing It Works

**Try this video (known to need PO Token):**
```
https://www.youtube.com/watch?v=jNQXAC9IVRw
```

**Before plugin:** Error - "No video formats found"  
**After plugin:** Downloads successfully!

## Complete Setup Checklist

For best YouTube download success, you need ALL of these:

### Required Software
- [ ] **Python 3.8+** installed
- [ ] **yt-dlp** latest: `pip install --upgrade yt-dlp`
- [ ] **Node.js** installed: https://nodejs.org/
- [ ] **bgutil-ytdlp-pot-provider**: `pip install bgutil-ytdlp-pot-provider`

### Configuration
- [ ] **Fresh cookies** exported from browser
- [ ] **Cookies loaded** in Download of Death

### Verify Everything Works
```bash
# Check yt-dlp version
yt-dlp --version

# Check Node.js
node --version

# Check plugin installed
pip show bgutil-ytdlp-pot-provider

# Test download
yt-dlp "https://www.youtube.com/watch?v=jNQXAC9IVRw"
```

## Troubleshooting

### Plugin not working?

**Check if it's installed:**
```bash
pip show bgutil-ytdlp-pot-provider
```

Should show:
```
Name: bgutil-ytdlp-pot-provider
Version: X.X.X
Location: ...
```

**If not installed:**
```bash
pip install bgutil-ytdlp-pot-provider
```

### Still getting errors?

**Update everything:**
```bash
pip install --upgrade yt-dlp
pip install --upgrade bgutil-ytdlp-pot-provider
```

**Restart app/terminal** - plugins load at startup

### Bundled executable not using plugin?

The plugin must be installed **before building**:

1. Install plugin: `pip install bgutil-ytdlp-pot-provider`
2. Clean: `rm -rf build dist` (or `rmdir /s /q build dist`)
3. Rebuild: `build_windows.bat` or `./build_macos.sh`

### Multiple Python versions?

Make sure you install to the **same Python** that runs yt-dlp:

```bash
# Check which Python yt-dlp uses
which yt-dlp   # macOS/Linux
where yt-dlp   # Windows

# Install plugin to correct Python
python3 -m pip install bgutil-ytdlp-pot-provider  # macOS/Linux
python -m pip install bgutil-ytdlp-pot-provider   # Windows
```

## Alternative: Manual Plugin Installation

If pip install doesn't work:

**1. Download the plugin:**
```bash
git clone https://github.com/Brainicism/bgutil-ytdlp-pot-provider.git
cd bgutil-ytdlp-pot-provider
```

**2. Install manually:**
```bash
pip install .
```

**3. Or copy to plugins folder:**
```bash
# Windows
mkdir %APPDATA%\yt-dlp\plugins
copy bgutil_ytdlp_pot_provider %APPDATA%\yt-dlp\plugins\

# macOS/Linux
mkdir -p ~/.yt-dlp/plugins
cp -r bgutil_ytdlp_pot_provider ~/.yt-dlp/plugins/
```

## How It Works

The plugin:
1. Integrates with yt-dlp as a "PO Token Provider"
2. Automatically generates tokens when YouTube requests them
3. Handles both web and mobile client tokens
4. Works transparently - no manual configuration

You don't need to:
- Extract tokens manually
- Pass tokens as command line arguments
- Configure anything

Just install and it works!

## Updating the Plugin

YouTube may update their protection, so keep the plugin updated:

```bash
pip install --upgrade bgutil-ytdlp-pot-provider
```

**Recommended:** Update monthly along with yt-dlp.

## Does This Fix Everything?

**What it fixes:**
- ✓ "No video formats found" errors
- ✓ "PO Token required" warnings
- ✓ "Requested format is not available" (PO Token-related)
- ✓ Most recent YouTube protection issues

**What you still need:**
- Node.js (for n parameter challenge)
- Fresh cookies (for authentication)
- Updated yt-dlp (for latest fixes)

**What might still not work:**
- Members-only content
- Some DRM-protected videos
- Active livestreams
- Region-locked content without VPN

## Quick Reference

**Install command:**
```bash
pip install bgutil-ytdlp-pot-provider
```

**Update command:**
```bash
pip install --upgrade bgutil-ytdlp-pot-provider
```

**Verify command:**
```bash
pip show bgutil-ytdlp-pot-provider
```

**Test command:**
```bash
yt-dlp "https://www.youtube.com/watch?v=jNQXAC9IVRw"
```

## Complete Solution Stack

For reliable YouTube downloads in 2025+:

1. **yt-dlp** (latest) - Core downloader
2. **Node.js** - Solves n parameter challenges  
3. **bgutil-ytdlp-pot-provider** - Generates PO Tokens
4. **Fresh cookies** - Authentication bypass
5. **Updated Download of Death** - GUI application

Install all of these and YouTube downloads work!

## Summary

This plugin is the **missing piece** for YouTube downloads. Without it, most videos won't download due to PO Token protection.

**Action steps:**
1. Run: `pip install bgutil-ytdlp-pot-provider`
2. Restart Download of Death
3. Try downloads - they should work now!

If building executable, install plugin first, then rebuild.

That's it - this plugin makes YouTube downloads work again!
