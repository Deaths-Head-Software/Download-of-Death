from __future__ import annotations

import sys
import time
from pathlib import Path
import threading

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QObject
from PyQt6.QtGui import (
    QFont, QPainter, QPixmap, QColor,
    QGuiApplication, QPalette, QIcon
)
from PyQt6.QtWidgets import (
    QApplication, QWidget, QLabel, QLineEdit, QPushButton,
    QVBoxLayout, QHBoxLayout, QFileDialog, QMessageBox,
    QComboBox, QProgressBar, QListWidget, QTextEdit,
    QSplashScreen, QCheckBox
)

import yt_dlp

APP_NAME = "Download of Death"
ORG_NAME = "Death's Head Software"
HISTORY_FILE = Path.home() / ".download_of_death_history.log"


# =============================================================================
# STDERR FILTER (suppresses harmless Python 3.14 http.client warnings)
# =============================================================================

import contextlib

class StderrFilter:
    """Filter out specific harmless error messages from stderr."""
    def __init__(self):
        self.stderr = sys.stderr if sys.stderr is not None else sys.__stderr__
        self.filtered_phrases = [
            "I/O operation on closed file",
            "Exception ignored while finalizing",
        ]
    
    def write(self, message):
        # Safely write, checking for None
        if self.stderr is None:
            return
        try:
            # Only write if message doesn't contain filtered phrases
            if not any(phrase in message for phrase in self.filtered_phrases):
                self.stderr.write(message)
        except (AttributeError, ValueError, OSError):
            # Ignore errors if stderr is closed or unavailable
            pass
    
    def flush(self):
        if self.stderr is not None:
            try:
                self.stderr.flush()
            except (AttributeError, ValueError, OSError):
                pass
    
    def fileno(self):
        if self.stderr is not None:
            try:
                return self.stderr.fileno()
            except (AttributeError, ValueError, OSError):
                return -1
        return -1

@contextlib.contextmanager
def suppress_http_warnings():
    """Temporarily filter stderr to hide harmless http.client warnings."""
    old_stderr = sys.stderr
    try:
        sys.stderr = StderrFilter()
        yield
    except Exception:
        # If anything goes wrong, restore stderr immediately
        sys.stderr = old_stderr
        raise
    finally:
        # Always restore original stderr
        sys.stderr = old_stderr


# =============================================================================
# FFMPEG PATH DETECTION
# =============================================================================

def get_ffmpeg_path():
    """Locate bundled FFmpeg executable - supports both --onefile and --onedir."""
    locations_to_check = []
    
    if getattr(sys, 'frozen', False):
        # Running as bundled executable
        base = Path(sys._MEIPASS)
        
        if sys.platform == "darwin":
            # For macOS --onedir, PyInstaller puts files in Contents/MacOS/ when using "."
            # Check multiple possible locations
            locations_to_check = [
                base,                        # Contents/MacOS/ (--onedir with ".")
                base / "ffmpeg",             # Contents/MacOS/ffmpeg/ (--onefile)
                base.parent / "Frameworks",  # Contents/Frameworks/ (if manually moved)
            ]
        elif sys.platform == "win32":
            locations_to_check = [base / "ffmpeg", base]
        else:  # Linux
            locations_to_check = [base / "ffmpeg", base]
    else:
        # Running as script
        locations_to_check = [Path(__file__).parent / "ffmpeg"]
    
    # Check each location
    for location in locations_to_check:
        if sys.platform == "win32":
            ffmpeg = location / "ffmpeg.exe"
            ffprobe = location / "ffprobe.exe"
        else:
            ffmpeg = location / "ffmpeg"
            ffprobe = location / "ffprobe"
        
        if ffmpeg.exists() and ffprobe.exists():
            return str(ffmpeg), str(ffprobe)
    
    return None, None


# =============================================================================
# ICON PATH DETECTION
# =============================================================================

def get_icon_path():
    """Locate bundled icon file for taskbar/window icon."""
    icon_name = "icon.ico" if sys.platform == "win32" else "icon.icns"
    
    if getattr(sys, 'frozen', False):
        # Running as bundled executable
        base = Path(sys._MEIPASS)
        icon_path = base / icon_name
        if icon_path.exists():
            return str(icon_path)
    else:
        # Running as script
        icon_path = Path(__file__).parent / icon_name
        if icon_path.exists():
            return str(icon_path)
    
    return None


# =============================================================================
# PALETTE (UNCHANGED)
# =============================================================================

def apply_light_palette(app):
    p = QPalette()
    window = QColor(245, 245, 245)
    base = QColor(255, 255, 255)
    button = QColor(235, 235, 235)
    text = QColor(20, 20, 20)
    highlight = QColor(30, 144, 255)

    for g in (QPalette.ColorGroup.Active, QPalette.ColorGroup.Inactive):
        p.setColor(g, QPalette.ColorRole.Window, window)
        p.setColor(g, QPalette.ColorRole.WindowText, text)
        p.setColor(g, QPalette.ColorRole.Base, base)
        p.setColor(g, QPalette.ColorRole.Text, text)
        p.setColor(g, QPalette.ColorRole.Button, button)
        p.setColor(g, QPalette.ColorRole.ButtonText, text)
        p.setColor(g, QPalette.ColorRole.Highlight, highlight)
        p.setColor(g, QPalette.ColorRole.HighlightedText, QColor(255, 255, 255))

    app.setPalette(p)


# =============================================================================
# SPLASH (RESTORED – 5.5s)
# =============================================================================

def create_splash(message: str):
    # Find splash.png in bundled app
    if getattr(sys, 'frozen', False):
        base = Path(sys._MEIPASS)
        # Check multiple possible locations for macOS
        if sys.platform == "darwin":
            splash_locations = [
                base / "splash.png",                        # MacOS folder (--onedir with ".")
                base / ".." / "Resources" / "splash.png",   # Resources folder (alternative)
                base.parent / "Resources" / "splash.png",   # Resources folder (alternative)
                base / "Resources" / "splash.png",          # If Resources is under _MEIPASS
            ]
        else:
            splash_locations = [base / "splash.png"]
        
        # DEBUG: Show what we're checking
        print(f"DEBUG: sys._MEIPASS = {base}")
        print(f"DEBUG: Resolved _MEIPASS = {base.resolve()}")
        for loc in splash_locations:
            exists = loc.exists()
            resolved = loc.resolve() if exists else "N/A"
            print(f"DEBUG: Checking {loc}")
            print(f"       Exists: {exists}, Resolved: {resolved}")
    else:
        splash_locations = [Path(__file__).parent / "splash.png"]
    
    # Try each location
    splash_path = None
    for loc in splash_locations:
        if loc.exists():
            splash_path = loc
            print(f"DEBUG: ✓ Found splash at: {splash_path.resolve()}")
            break
    
    if not splash_path:
        print("DEBUG: ✗ Splash not found in any location, using white background")
    
    if splash_path:
        pixmap = QPixmap(str(splash_path)).scaled(
            800, 600,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation
        )
    else:
        pixmap = QPixmap(800, 600)
        pixmap.fill(QColor(255, 255, 255))

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)

    painter.setPen(QColor("white"))
    painter.setFont(QFont("Courier", 34, QFont.Weight.Bold))
    painter.drawText(pixmap.rect().adjusted(0, 40, 0, -480), Qt.AlignmentFlag.AlignCenter, APP_NAME)

    painter.setFont(QFont("Courier", 12))
    painter.drawText(pixmap.rect().adjusted(0, 480, 0, -90), Qt.AlignmentFlag.AlignCenter, ORG_NAME)

    painter.setFont(QFont("Courier", 11))
    painter.drawText(pixmap.rect().adjusted(0, 520, 0, 0), Qt.AlignmentFlag.AlignCenter, message)

    painter.end()
    return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)


# =============================================================================
# PROGRESS EMITTER
# =============================================================================

class ProgressEmitter(QObject):
    progress = pyqtSignal(int)
    status = pyqtSignal(str)


# =============================================================================
# DOWNLOAD WORKER (FIXED CANCEL / VERBOSE)
# =============================================================================

class DownloadWorker(QThread):
    finished = pyqtSignal(bool)  # True = normal, False = cancelled
    error = pyqtSignal(str)

    def __init__(self, url, out_dir, fmt, emitter, cookies_file=None, verbose=False):
        super().__init__()
        self.url = url
        self.out_dir = out_dir
        self.fmt = fmt
        self.emitter = emitter
        self.cookies_file = cookies_file
        self.verbose = verbose

        self._pause = threading.Event()
        self._pause.set()
        self._cancelled = False

    def pause(self):
        self.emitter.status.emit("Paused")
        self._pause.clear()

    def resume(self):
        self.emitter.status.emit("Resuming download…")
        self._pause.set()

    def cancel(self):
        self._cancelled = True
        self._pause.set()
        self.emitter.status.emit("Cancelling current download…")

    def run(self):
        try:
            # Verify output directory exists and is valid
            if not self.out_dir or not isinstance(self.out_dir, Path):
                raise Exception("Invalid output directory")
            
            # Ensure output directory exists
            try:
                self.out_dir.mkdir(parents=True, exist_ok=True)
            except Exception as e:
                raise Exception(f"Cannot create output directory: {e}")
            
            def hook(d):
                while not self._pause.is_set():
                    time.sleep(0.2)

                if self._cancelled:
                    raise StopIteration

                if d["status"] == "downloading":
                    downloaded = d.get("downloaded_bytes", 0)
                    total = d.get("total_bytes") or d.get("total_bytes_estimate", 1)
                    pct = int((downloaded / max(total, 1)) * 100)
                    self.emitter.progress.emit(pct)
                    self.emitter.status.emit(f"Downloading… {pct}%")

                elif d["status"] == "finished":
                    self.emitter.progress.emit(100)
                    self.emitter.status.emit("Finalizing file…")

            # Get bundled FFmpeg paths
            ffmpeg_path, ffprobe_path = get_ffmpeg_path()
            
            opts = {
                "outtmpl": str(self.out_dir / "%(title)s.%(ext)s"),
                "progress_hooks": [hook],
                "quiet": not self.verbose,
                "no_warnings": not self.verbose,
                "verbose": self.verbose,
                "noplaylist": True,
                "force_ipv4": True,
                "retries": 10,
                "fragment_retries": 10,
                "skip_unavailable_fragments": True,
                # Let yt-dlp and the plugin handle YouTube's protection
                "extractor_args": {
                    "youtube": {
                        # Try multiple clients - the plugin will handle PO tokens automatically
                        "player_client": ["android", "ios", "web", "mweb"],
                    }
                },
            }
            
            # Add FFmpeg paths if bundled
            if ffmpeg_path:
                opts["ffmpeg_location"] = str(Path(ffmpeg_path).parent)
            
            # Add cookies if provided (helps bypass YouTube bot detection)
            if self.cookies_file:
                opts["cookiefile"] = str(self.cookies_file)

            if self.fmt in ("MP3", "WAV", "FLAC"):
                opts.update({
                      "format": "bestaudio/best",
                      "postprocessors": [{
                            "key": "FFmpegExtractAudio",
                            "preferredcodec": self.fmt.lower(),
                            "preferredquality": "0",
                     }],
                })

            else:
                # Simpler format selection that works with or without Node.js
                opts.update({
                    "format": "bv*+ba/b",  # Best video + audio, or best combined
                    "merge_output_format": self.fmt.lower(),
                })

            with suppress_http_warnings():
                with yt_dlp.YoutubeDL(opts) as ydl:
                    # Get info first to check availability
                    info = ydl.extract_info(self.url, download=False)
                    
                    if not info:
                        raise Exception("Could not extract video information")
                    
                    # Now download
                    ydl.download([self.url])
                    
                    # Verify file was created and has content
                    expected_filename = ydl.prepare_filename(info)
                    output_file = Path(expected_filename)
                    
                    # Check if file exists and has size
                    if output_file.exists():
                        file_size = output_file.stat().st_size
                        if file_size == 0:
                            raise Exception(f"Downloaded file is empty (0 bytes). The video may be region-locked, private, or unavailable.")
                        self.emitter.status.emit(f"Download complete! ({file_size / 1024 / 1024:.1f} MB)")
                    else:
                        # Check if a converted file exists (for audio conversions)
                        for ext in ['mp3', 'wav', 'flac', 'mp4', 'mkv']:
                            converted = output_file.with_suffix(f'.{ext}')
                            if converted.exists() and converted.stat().st_size > 0:
                                output_file = converted
                                file_size = output_file.stat().st_size
                                self.emitter.status.emit(f"Download complete! ({file_size / 1024 / 1024:.1f} MB)")
                                break
                        else:
                            raise Exception("Downloaded file not found after completion")

            self.finished.emit(True)

        except StopIteration:
            self.emitter.progress.emit(0)
            self.finished.emit(False)

        except Exception as e:
            error_msg = str(e)
            
            # Provide helpful error messages for common issues
            if "Requested format is not available" in error_msg or "Only images are available" in error_msg or "No video formats found" in error_msg:
                self.error.emit(
                    "YouTube PO Token Protection\n\n"
                    "YouTube has blocked video access with their latest anti-bot protection.\n\n"
                    "SOLUTION (fixes most issues):\n\n"
                    "Install PO Token Provider Plugin:\n"
                    "1. Open Command Prompt and run:\n"
                    "   pip install bgutil-ytdlp-pot-provider\n"
                    "2. Restart Download of Death\n"
                    "3. Try download again\n\n"
                    "This plugin automatically generates the PO Tokens\n"
                    "YouTube requires for downloads.\n\n"
                    "Also ensure:\n"
                    "• yt-dlp is updated: pip install --upgrade yt-dlp\n"
                    "• Node.js is installed: https://nodejs.org/\n"
                    "• Fresh cookies are loaded\n\n"
                    f"Technical: {error_msg[:150]}..."
                )
            elif "403" in error_msg or "forbidden" in error_msg.lower():
                self.error.emit(
                    "YouTube Download Blocked (403 Forbidden)\n\n"
                    "YouTube is blocking this download due to their anti-bot protection.\n\n"
                    "SOLUTION: Install Node.js to solve YouTube's challenges\n\n"
                    "1. Download Node.js from: https://nodejs.org/\n"
                    "2. Install it (keep default settings)\n"
                    "3. Restart Download of Death\n"
                    "4. Try download again\n\n"
                    "Alternative: Some videos may not be downloadable due to restrictions.\n\n"
                    f"Technical details: {error_msg[:200]}..."
                )
            elif "empty" in error_msg.lower():
                self.error.emit(
                    "Empty Download Error\n\n"
                    "Possible causes:\n"
                    "• Video is region-locked or geo-restricted\n"
                    "• Video requires login/cookies (click 'Select Cookies File')\n"
                    "• Video is private or deleted\n"
                    "• Network connection interrupted\n\n"
                    f"Technical details: {error_msg}"
                )
            elif "429" in error_msg or "too many requests" in error_msg.lower():
                self.error.emit(
                    "Rate Limited\n\n"
                    "YouTube is throttling requests. Try:\n"
                    "• Wait a few minutes and try again\n"
                    "• Use cookies file (click 'Select Cookies File')\n"
                    "• Check your internet connection\n\n"
                    f"Technical details: {error_msg}"
                )
            else:
                self.error.emit(error_msg)


# =============================================================================
# MAIN WINDOW
# =============================================================================

class DownloadOfDeath(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(760, 520)
        self.setFont(QFont("Courier", 10))

        self.queue = []
        self.output_dir = None
        self.cookies_file = None
        self.worker = None
        self.emitter = ProgressEmitter()

        self._build_ui()
        self._connect()

    def _build_ui(self):
        self.url_input = QLineEdit()
        self.add_btn = QPushButton("Add to Queue")
        self.queue_list = QListWidget()

        self.format_box = QComboBox()
        self.format_box.addItems(["MP4", "MKV", "MP3", "WAV", "FLAC"])

        self.output_btn = QPushButton("Select Output Folder")
        self.output_label = QLabel("No folder selected")
        
        self.cookies_btn = QPushButton("Select Cookies File (Optional)")
        self.cookies_label = QLabel("No cookies file selected")
        self.cookies_label.setStyleSheet("color: gray; font-style: italic;")
        
        # Add verbose mode checkbox for troubleshooting
        self.verbose_check = QCheckBox("Verbose Mode (for troubleshooting)")
        self.verbose_check.setToolTip("Shows detailed download information to help diagnose issues")

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.status = QLabel("Idle")

        self.start_btn = QPushButton("Start Queue")
        self.pause_btn = QPushButton("Pause")
        self.resume_btn = QPushButton("Resume")
        self.cancel_btn = QPushButton("Cancel Current")
        self.help_btn = QPushButton("Help: Bot Detection")

        layout = QVBoxLayout(self)
        layout.addWidget(self.url_input)
        layout.addWidget(self.add_btn)
        layout.addWidget(self.queue_list)
        layout.addWidget(self.format_box)
        layout.addWidget(self.output_btn)
        layout.addWidget(self.output_label)
        layout.addWidget(self.cookies_btn)
        layout.addWidget(self.cookies_label)
        layout.addWidget(self.verbose_check)
        layout.addWidget(self.progress)
        layout.addWidget(self.status)

        row = QHBoxLayout()
        for b in (self.start_btn, self.pause_btn, self.resume_btn, self.cancel_btn):
            row.addWidget(b)
        layout.addLayout(row)
        layout.addWidget(self.help_btn)

    def _connect(self):
        self.add_btn.clicked.connect(self.add_url)
        self.output_btn.clicked.connect(self.pick_folder)
        self.cookies_btn.clicked.connect(self.pick_cookies)
        self.start_btn.clicked.connect(self.start_queue)
        self.help_btn.clicked.connect(self.show_help)

        self.pause_btn.clicked.connect(lambda: self.worker.pause() if self.worker else None)
        self.resume_btn.clicked.connect(lambda: self.worker.resume() if self.worker else None)
        self.cancel_btn.clicked.connect(lambda: self.worker.cancel() if self.worker else None)

        self.emitter.progress.connect(self.progress.setValue)
        self.emitter.status.connect(self.status.setText)

    def add_url(self):
        if self.url_input.text():
            self.queue.append(self.url_input.text())
            self.queue_list.addItem(self.url_input.text())
            self.url_input.clear()

    def pick_folder(self):
        f = QFileDialog.getExistingDirectory(self, "Select Output Folder")
        if f:
            self.output_dir = Path(f)
            self.output_label.setText(str(self.output_dir))
    
    def pick_cookies(self):
        f, _ = QFileDialog.getOpenFileName(
            self, 
            "Select Cookies File",
            str(Path.home()),
            "Text Files (*.txt);;All Files (*.*)"
        )
        if f:
            self.cookies_file = Path(f)
            self.cookies_label.setText(str(self.cookies_file))
            self.cookies_label.setStyleSheet("color: green;")
            QMessageBox.information(
                self,
                APP_NAME,
                "Cookies file loaded! This should help bypass YouTube's bot detection."
            )
    
    def show_help(self):
        help_text = """<h3>YouTube Bot Detection Fix</h3>
        
<p>If you see "Sign in to confirm you're not a bot" errors:</p>

<h4>Quick Fix:</h4>
<ol>
<li><b>Install browser extension:</b><br>
   • Chrome/Edge: "Get cookies.txt LOCALLY"<br>
   • Firefox: "cookies.txt"</li>

<li><b>Export cookies:</b><br>
   • Go to youtube.com (logged in)<br>
   • Click extension icon<br>
   • Click "Export"<br>
   • Save as youtube_cookies.txt</li>

<li><b>Load in app:</b><br>
   • Click "Select Cookies File"<br>
   • Choose your saved cookies file<br>
   • Try download again!</li>
</ol>

<h4>Important:</h4>
<p>⚠️ Keep cookies file private - it's like your password!<br>
⚠️ Re-export every few months when cookies expire</p>

<h4>Extension Links:</h4>
<p>Chrome: chrome.google.com/webstore<br>
   Search: "Get cookies.txt LOCALLY"</p>
<p>Firefox: addons.mozilla.org<br>
   Search: "cookies.txt"</p>
"""
        msg = QMessageBox(self)
        msg.setWindowTitle(f"{APP_NAME} - Help")
        msg.setTextFormat(Qt.TextFormat.RichText)
        msg.setText(help_text)
        msg.setStandardButtons(QMessageBox.StandardButton.Ok)
        msg.exec()

    def start_queue(self):
        if not self.queue or not self.output_dir:
            QMessageBox.warning(self, APP_NAME, "Queue empty or output folder missing.")
            return
        self.start_btn.setEnabled(False)
        self.status.setText("Starting queue…")
        self._next()

    def _next(self):
        if not self.queue:
            self.status.setText("Queue complete.")
            self.start_btn.setEnabled(True)
            return

        url = self.queue.pop(0)
        self.queue_list.takeItem(0)
        self.progress.setValue(0)
        self.status.setText(f"Preparing: {url}")

        self.worker = DownloadWorker(
            url, 
            self.output_dir, 
            self.format_box.currentText(), 
            self.emitter,
            self.cookies_file,
            self.verbose_check.isChecked()
        )
        self.worker.finished.connect(self._on_finished)
        self.worker.error.connect(self._on_error)
        self.worker.start()
    
    def _on_error(self, error_msg):
        # Check if it's a bot detection error
        if "Sign in to confirm you're not a bot" in error_msg or "LOGIN_REQUIRED" in error_msg:
            # Check if we have cookies loaded but they're invalid
            if self.cookies_file:
                QMessageBox.critical(
                    self, 
                    APP_NAME,
                    "Cookies File Expired!\n\n"
                    "Your cookies file is loaded but no longer valid.\n"
                    "YouTube rotated your cookies for security.\n\n"
                    "TO FIX:\n\n"
                    "1. Go to YouTube in your browser (make sure you're logged in)\n"
                    "2. Click your cookies export extension\n"
                    "3. Export cookies again (overwrites old file)\n"
                    "4. In Download of Death, click 'Select Cookies File'\n"
                    "5. Choose the NEW cookies file\n"
                    "6. Try download again\n\n"
                    "Note: Cookies expire regularly - you may need to\n"
                    "re-export them every few weeks.\n\n"
                    f"Technical error:\n{error_msg[:200]}..."
                )
            else:
                QMessageBox.critical(
                    self, 
                    APP_NAME,
                    "YouTube Bot Detection Error\n\n"
                    "YouTube has blocked this download. To fix:\n\n"
                    "1. Click 'Select Cookies File'\n"
                    "2. Export cookies from your browser using an extension\n"
                    "   (search for 'cookies.txt' extension for your browser)\n"
                    "3. Select the exported cookies file\n"
                    "4. Try downloading again\n\n"
                    f"Technical error:\n{error_msg[:200]}..."
                )
        elif "cookies" in error_msg.lower() and "invalid" in error_msg.lower():
            QMessageBox.critical(
                self,
                APP_NAME,
                "Invalid Cookies File\n\n"
                "The cookies file format is incorrect or corrupted.\n\n"
                "TO FIX:\n\n"
                "1. Re-export cookies using the browser extension\n"
                "2. Make sure you export from youtube.com (not google.com)\n"
                "3. The file should be plain text, not JSON\n"
                "4. Try selecting the new cookies file\n\n"
                f"Technical error:\n{error_msg[:200]}..."
            )
        else:
            QMessageBox.critical(self, APP_NAME, f"Download Error:\n\n{error_msg}")
    

    def _on_finished(self, success: bool):
        if success:
            self.status.setText("Download completed. Moving to next item…")
        else:
            self.status.setText("Download cancelled. Skipping to next item…")
        self._next()


# =============================================================================
# ENTRY
# =============================================================================

def main():
    # On Windows, set application ID for proper taskbar icon grouping
    if sys.platform == "win32":
        try:
            import ctypes
            # Set application user model ID for taskbar icon
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                'DeathsHeadSoftware.DownloadOfDeath.1.0'
            )
        except:
            pass
    
    app = QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setOrganizationName(ORG_NAME)
    
    # Set application icon for taskbar - MUST be set before creating windows
    icon_path = get_icon_path()
    if icon_path:
        icon = QIcon(icon_path)
        if not icon.isNull():
            app.setWindowIcon(icon)
            # On Windows, also set as the default icon
            if sys.platform == "win32":
                QApplication.setWindowIcon(icon)
        else:
            print(f"Warning: Could not load icon from {icon_path}")
    else:
        print("Warning: Icon file not found")
    
    apply_light_palette(app)

    splash = create_splash("Initializing Download Engine…")
    splash.show()
    app.processEvents()
    time.sleep(5.5)

    win = DownloadOfDeath()
    
    # Set window icon as well
    if icon_path:
        icon = QIcon(icon_path)
        if not icon.isNull():
            win.setWindowIcon(icon)
    
    win.show()
    splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
